$(function () {
    $(window).scroll(function(){
        var top=$(document).scrollTop();
        if(top>100)
            $('.navbar-fixed-top').addClass('animated').css({'animationName':'bounce '});
        else
            $('.navbar-fixed-top').removeClass('animated').removeAttr('style');
    });	 // 固定导航

    $("i.nav_bar").click(function(){
        if($(this).hasClass('fa-bars'))
        {
            $(this).removeClass('fa-bars').addClass(' fa-times')
        }
        else
        {
            $(this).removeClass('fa-times').addClass('fa-bars');
        }
    });// 切换导航

    //导航点击下拉框
    $('a.dropdown-toggle').click(function(){
        $('.dropdown>.dropdown-menu').slideToggle();
    });
});