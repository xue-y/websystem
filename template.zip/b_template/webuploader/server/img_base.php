<?php
		$image_file=$_FILES['file']['tmp_name'];
        $image_info = getimagesize($image_file);

        $image_data = fread(fopen($image_file, 'r'), filesize($image_file));
        $base64_image = 'data:' . $image_info['mime'] . ';base64,' . chunk_split(base64_encode($image_data));
        //ajax 返回
        $data['code']='ok';
        $data['data']=$base64_image;
        return json_encode($data);