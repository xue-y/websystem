<?php
var_dump($_FILES);
echo '--------------------';
var_dump($_REQUEST);
exit;